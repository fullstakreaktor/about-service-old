import React from 'react';
import ReactDOM from 'react-dom';
import App from './components/App.jsx';

ReactDOM.render(<App id='86' listingId='56' />,document.getElementById('app'));
